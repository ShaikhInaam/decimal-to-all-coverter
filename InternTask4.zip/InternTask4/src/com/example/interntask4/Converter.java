package com.example.interntask4;

public class Converter {

	int binary,octal;
	String hexa;
	
	 public void binary(int number) {
		 
		 int a=Integer.parseInt(Integer.toBinaryString(number));
		 binary=a;
	    }
	 
	 public int getBinary()
	 {
		 return binary;
	 }
	
	public void octal(int number)
	{
		int a=Integer.parseInt(Integer.toOctalString(number));
		octal=a;
	}
	
	public int getOctal()
	{
		return octal;
	}
	
	public void hexa(int number)
	{
		String a=Integer.toHexString(number);
		hexa=a;
	}
	
	public String getHexa()
	{
		return hexa;
	}
	

	
}
