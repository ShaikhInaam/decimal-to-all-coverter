package com.example.interntask4;

import java.util.ArrayList;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

	Converter c=new Converter();
	EditText value;
	Spinner spin;
	TextView res;
	int x;
	
	public void spinWork()
	{
		ArrayList<String> list=new ArrayList<String>();
		list.add("Select Conversion");
		list.add("Convert into Binary");
		list.add("Convert into Octal");
		list.add("Convert into Hexa");
		
		ArrayAdapter<String> ad=new ArrayAdapter<String>(getApplicationContext(),R.layout.activity,R.id.text,list);
		spin.setAdapter(ad);
		spin.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> parent, View view,
					int position, long id) {
				// TODO Auto-generated method stub
				x=position;
			}

			@Override
			public void onNothingSelected(AdapterView<?> parent) {
				// TODO Auto-generated method stub
				
			}
			
			
		});
	}
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_main);
		
		value=(EditText)findViewById(R.id.editText1);
		spin=(Spinner)findViewById(R.id.spinner1);
		res=(TextView)findViewById(R.id.textView1);
		spinWork();
	}
	
	public void result(View v)
	{
		if(value.getText().toString().equals(""))
		{
			Toast.makeText(getApplicationContext(), "empty values not allowed", 5000).show();
		}
		
	else if(x==1)
		{
			c.binary(Integer.parseInt(value.getText().toString()));
			value.setText("");
			res.setText("Result is: "+c.getBinary());
		}
		
	else if(x==2)
		{
			c.octal(Integer.parseInt(value.getText().toString()));
			value.setText("");
			res.setText("Result is: "+c.getOctal());
		}
		
	else if(x==3)
		{
			c.hexa(Integer.parseInt(value.getText().toString()));
			value.setText("");
			res.setText("Result is: "+c.getHexa());
		}
		
	else if(x==0)
		{

			Toast.makeText(getApplicationContext(), "select conversion first", 5000).show();
		}
	}

}
